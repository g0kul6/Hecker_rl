# Environment Schema

Citylearn settings are controlled by schema files, such as `citylearn_challenge_2022_phase_1/schema.json`.

Feel free to modify the schema for your local evalution as you see fit, the evaluator will **not** use any schema you add here.